# Ellie's Animal Puzzles (Android)

Jigsaw puzzles for kids, led by Ellie the Elephant: 10 animal pictures, 3 levels each (4, 9 or 12 pieces),
sound effects and music, a spoken voice (Android Text-to-Speech), vibration, stars that are saved, and a
confetti, balloon and fanfare celebration when a puzzle is finished.

The game itself is in `app/src/main/assets/` (HTML5). `MainActivity.java` shows it full-screen in a WebView.

## Get the APK, option A: GitHub (no software to install)
1. Create a new **private** repository on github.com, then upload the contents of this folder
   (choose "uploading an existing file" and drag everything in, **including the hidden `.github` folder**).
2. Open the **Actions** tab. The "Build APK" run starts on its own and takes about 4 minutes.
3. When it shows a green check, open the run and download **EllieAnimalPuzzles-apk** (a zip holding the APK).

## Get the APK, option B: Android Studio
Open this folder in Android Studio, let it sync, then choose **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.

## Install it on the Samsung phone
Copy the APK to the phone (Google Drive, email or USB) and tap it. If Android asks, allow
"Install unknown apps" for the app you opened it with (My Files, Chrome or Drive).
If Play Protect warns about an unrecognized app, tap **More details > Install anyway**. This happens because the app
isn't from the Play Store.
