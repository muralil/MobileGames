/* Ellie's Animal Puzzles — game engine */
(function () {
  'use strict';
  const $ = (s) => document.querySelector(s);
  const store = {
    get(k, d) { try { const v = localStorage.getItem('ellie_' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('ellie_' + k, JSON.stringify(v)); } catch (e) { } }
  };
  const rnd = (a, b) => a + Math.random() * (b - a);
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

  // ------------------------------------------------------------------ data
  const PUZZLES = [
    { id: 'ellie', name: 'Ellie', full: 'Ellie the Elephant', say: 'Toot toot!', fact: 'Elephants use their long trunks to drink, smell and say hello!' },
    { id: 'family', name: 'Elephant Family', full: 'the Elephant Family', say: 'Toot toot!', fact: 'Baby elephants stay close to their mommy and their family herd.' },
    { id: 'lion', name: 'Lion', full: 'the Lion', say: 'Roar!', fact: 'A lion\'s roar can be heard far, far away!' },
    { id: 'giraffe', name: 'Giraffe', full: 'the Giraffe', say: 'Hmmmm!', fact: 'Giraffes are the tallest animals in the whole world.' },
    { id: 'monkey', name: 'Monkey', full: 'the Monkey', say: 'Ooh ooh, ah ah!', fact: 'Monkeys love bananas and swinging in the trees.' },
    { id: 'hippo', name: 'Hippo', full: 'the Hippo', say: 'Splash!', fact: 'Hippos love to stay cool in the water all day long.' },
    { id: 'panda', name: 'Panda', full: 'the Panda', say: 'Munch munch!', fact: 'Pandas eat bamboo for most of the day.' },
    { id: 'zebra', name: 'Zebra', full: 'the Zebra', say: 'Neigh!', fact: 'Every zebra has its very own stripe pattern.' },
    { id: 'turtle', name: 'Turtle', full: 'the Turtle', say: 'Slow and steady!', fact: 'A turtle carries its home, its shell, on its back.' },
    { id: 'owl', name: 'Owl', full: 'the Owl', say: 'Hoo hoo!', fact: 'Owls stay awake at night and sleep during the day.' }
  ];
  const LEVELS = [
    { c: 2, r: 2, label: 'Easy', icon: '🐣' },
    { c: 3, r: 3, label: 'Medium', icon: '🐘' },
    { c: 4, r: 3, label: 'Hard', icon: '🦁' }
  ];
  const PRAISE = ['Great job!', 'Yes!', 'You found it!', 'Super!', 'Wow!', 'Well done!', 'Perfect!', 'Hooray!', 'Nice!'];

  const urls = {}, images = {};
  PUZZLES.forEach((p) => { urls[p.id] = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(ART.scenes[p.id]()); });
  const ellieURL = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(ART.elephantSVG({ bow: true }));
  const ellieHatURL = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(ART.elephantSVG({ hat: true, color: '#b9c3cf' }));
  function loadImg(id) {
    return new Promise((res) => {
      if (images[id] && images[id].complete) return res(images[id]);
      const im = new Image();
      im.onload = () => res(im);
      im.onerror = () => res(im);
      im.src = urls[id];
      images[id] = im;
    });
  }

  // ------------------------------------------------------------------ sound
  const Snd = (function () {
    let ctx = null, master, sfx, musicGain, timer = null, nextT = 0, step = 0;
    let on = store.get('snd', true), music = store.get('mus', true);
    function init() {
      try {
        if (!ctx) {
          const AC = window.AudioContext || window.webkitAudioContext;
          if (!AC) return;
          ctx = new AC();
          master = ctx.createGain(); master.gain.value = on ? 1 : 0; master.connect(ctx.destination);
          sfx = ctx.createGain(); sfx.gain.value = 0.9; sfx.connect(master);
          musicGain = ctx.createGain(); musicGain.gain.value = music ? 0.13 : 0; musicGain.connect(master);
          startMusic();
        }
        if (ctx.state !== 'running') ctx.resume();
      } catch (e) { }
    }
    function tone(f, dur, type, vol, when, slide, dest) {
      if (!ctx) return;
      const t = ctx.currentTime + (when || 0);
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = type || 'sine';
      o.frequency.setValueAtTime(f, t);
      if (slide) o.frequency.exponentialRampToValueAtTime(slide, t + dur);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(vol || 0.2, t + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(dest || sfx);
      o.start(t); o.stop(t + dur + 0.05);
    }
    let noiseBuf = null;
    function noise(dur, vol, when, freq, q) {
      if (!ctx) return;
      if (!noiseBuf) {
        noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
        const d = noiseBuf.getChannelData(0);
        for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      }
      const t = ctx.currentTime + (when || 0);
      const s = ctx.createBufferSource(); s.buffer = noiseBuf;
      const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = freq || 2000; f.Q.value = q || 1;
      const g = ctx.createGain();
      g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      s.connect(f); f.connect(g); g.connect(sfx);
      s.start(t); s.stop(t + dur + 0.05);
    }
    const N = (n) => 440 * Math.pow(2, (n - 69) / 12);
    const api = {
      init,
      get on() { return on; }, get music() { return music; },
      toggle() { on = !on; store.set('snd', on); if (master) master.gain.value = on ? 1 : 0; if (!on) stopSpeech(); return on; },
      toggleMusic() { music = !music; store.set('mus', music); if (musicGain) musicGain.gain.setTargetAtTime(music ? 0.13 : 0, ctx.currentTime, 0.1); return music; },
      suspend() { try { ctx && ctx.suspend(); } catch (e) { } },
      resume() { try { ctx && ctx.resume(); } catch (e) { } },
      tap() { tone(700, 0.07, 'triangle', 0.15); },
      pick() { tone(480, 0.12, 'sine', 0.25, 0, 900); },
      drop() { tone(320, 0.14, 'triangle', 0.18, 0, 200); },
      snap() {
        tone(N(84), 0.09, 'triangle', 0.3); tone(N(91), 0.18, 'sine', 0.25, 0.06);
        noise(0.05, 0.25, 0, 3500, 2);
      },
      sparkle() { [88, 91, 95, 100, 103].forEach((n, i) => tone(N(n), 0.3, 'sine', 0.1, i * 0.055)); },
      fanfare() {
        const seq = [[72, 0], [76, 0.14], [79, 0.28], [84, 0.42]];
        seq.forEach(([n, t]) => { tone(N(n), 0.22, 'square', 0.07, t); tone(N(n), 0.25, 'triangle', 0.18, t); });
        [72, 76, 79, 84].forEach((n) => { tone(N(n), 1.1, 'triangle', 0.14, 0.6); tone(N(n), 1.0, 'square', 0.035, 0.6); });
        for (let i = 0; i < 14; i++) noise(0.08, 0.18, 0.6 + i * 0.06 + Math.random() * 0.04, rnd(1500, 4000), 1.5);
      },
      trumpet(when) {
        if (!ctx) return;
        const t = ctx.currentTime + (when || 0);
        const o = ctx.createOscillator(); o.type = 'sawtooth';
        const lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = 9; lg.gain.value = 14;
        lfo.connect(lg); lg.connect(o.frequency);
        o.frequency.setValueAtTime(220, t);
        o.frequency.exponentialRampToValueAtTime(560, t + 0.18);
        o.frequency.setValueAtTime(560, t + 0.5);
        o.frequency.exponentialRampToValueAtTime(420, t + 0.95);
        const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1300; bp.Q.value = 1.4;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.5, t + 0.08);
        g.gain.setValueAtTime(0.45, t + 0.8); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.05);
        o.connect(bp); bp.connect(g); g.connect(sfx);
        o.start(t); lfo.start(t); o.stop(t + 1.1); lfo.stop(t + 1.1);
      },
      whoosh() { noise(0.35, 0.12, 0, 900, 0.6); }
    };
    // gentle marimba loop
    const MEL = [72, null, 76, 79, 81, null, 79, 76, 74, null, 76, 72, 69, null, 72, null,
      72, null, 76, 79, 84, null, 81, 79, 76, null, 74, 76, 72, null, null, null];
    const BASS = [48, 53, 55, 48];
    function marimba(n, t, v) {
      const o = ctx.createOscillator(), o2 = ctx.createOscillator(), g = ctx.createGain(), g2 = ctx.createGain();
      o.type = 'sine'; o2.type = 'sine'; o.frequency.value = N(n); o2.frequency.value = N(n) * 4;
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.6);
      g2.gain.setValueAtTime(0.0001, t); g2.gain.exponentialRampToValueAtTime(v * 0.25, t + 0.005); g2.gain.exponentialRampToValueAtTime(0.0001, t + 0.12);
      o.connect(g); o2.connect(g2); g.connect(musicGain); g2.connect(musicGain);
      o.start(t); o2.start(t); o.stop(t + 0.7); o2.stop(t + 0.2);
    }
    function startMusic() {
      if (timer) return;
      nextT = ctx.currentTime + 0.2;
      timer = setInterval(() => {
        if (!ctx || ctx.state !== 'running') return;
        while (nextT < ctx.currentTime + 0.3) {
          const n = MEL[step % MEL.length];
          if (n) marimba(n, nextT, 0.5);
          if (step % 4 === 0) marimba(BASS[(step / 4 | 0) % BASS.length], nextT, 0.45);
          step++; nextT += 0.27;
        }
      }, 90);
    }
    return api;
  })();

  function stopSpeech() {
    try { if (window.Android && Android.stopSpeaking) Android.stopSpeaking(); else if (window.speechSynthesis) speechSynthesis.cancel(); } catch (e) { }
  }
  function say(text) {
    if (!Snd.on) return;
    try {
      if (window.Android && Android.speak) { Android.speak(text); return; }
      if ('speechSynthesis' in window) {
        speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(text);
        u.rate = 0.95; u.pitch = 1.35; u.lang = 'en-US';
        speechSynthesis.speak(u);
      }
    } catch (e) { }
  }
  function buzz(ms) {
    try { if (window.Android && Android.vibrate) Android.vibrate(ms); else if (navigator.vibrate) navigator.vibrate(ms); } catch (e) { }
  }

  // ------------------------------------------------------------------ fx canvas (sparkles + confetti)
  const FX = (function () {
    const cv = $('#fx'), ctx = cv.getContext('2d');
    let parts = [], running = false, dpr = 1;
    function size() { dpr = Math.min(window.devicePixelRatio || 1, 2); cv.width = innerWidth * dpr; cv.height = innerHeight * dpr; cv.style.width = innerWidth + 'px'; cv.style.height = innerHeight + 'px'; }
    size(); addEventListener('resize', size);
    const COLORS = ['#ff6fa3', '#ffd84d', '#4cd27a', '#4cb8f0', '#b07cff', '#ff8a3d'];
    function loop() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, innerWidth, innerHeight);
      parts = parts.filter((p) => p.life > 0);
      for (const p of parts) {
        p.life -= 1; p.x += p.vx; p.y += p.vy; p.vy += p.g; p.vx *= p.drag; p.vy *= p.drag; p.rot += p.vr;
        const a = Math.min(1, p.life / 25);
        ctx.save(); ctx.globalAlpha = a; ctx.translate(p.x, p.y); ctx.rotate(p.rot);
        ctx.fillStyle = p.c;
        if (p.kind === 'star') { star(ctx, p.s); }
        else if (p.kind === 'circle') { ctx.beginPath(); ctx.arc(0, 0, p.s, 0, 7); ctx.fill(); }
        else { ctx.scale(1, Math.cos(p.rot * 3)); ctx.fillRect(-p.s, -p.s * 0.5, p.s * 2, p.s); }
        ctx.restore();
      }
      if (parts.length) requestAnimationFrame(loop); else { running = false; ctx.clearRect(0, 0, innerWidth, innerHeight); }
    }
    function star(c, r) {
      c.beginPath();
      for (let i = 0; i < 10; i++) { const a = i * Math.PI / 5 - Math.PI / 2, rr = i % 2 ? r * 0.45 : r; c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
      c.closePath(); c.fill();
    }
    function kick() { if (!running) { running = true; requestAnimationFrame(loop); } }
    return {
      sparkle(x, y, n) {
        for (let i = 0; i < (n || 16); i++) {
          const a = rnd(0, Math.PI * 2), v = rnd(2, 6);
          parts.push({ kind: i % 3 ? 'star' : 'circle', x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: 0.05, drag: 0.95, rot: rnd(0, 6), vr: rnd(-0.2, 0.2), s: rnd(4, 9), c: pick(COLORS), life: rnd(30, 50) });
        }
        kick();
      },
      confetti(x, y, n, spread) {
        for (let i = 0; i < n; i++) {
          const a = -Math.PI / 2 + rnd(-spread, spread), v = rnd(8, 17);
          parts.push({ kind: Math.random() < 0.2 ? 'star' : 'rect', x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: 0.28, drag: 0.985, rot: rnd(0, 6), vr: rnd(-0.3, 0.3), s: rnd(5, 9), c: pick(COLORS), life: rnd(110, 170) });
        }
        kick();
      },
      rain(n) {
        for (let i = 0; i < n; i++) {
          parts.push({ kind: 'rect', x: rnd(0, innerWidth), y: rnd(-innerHeight * 0.6, -10), vx: rnd(-1, 1), vy: rnd(2, 5), g: 0.05, drag: 0.995, rot: rnd(0, 6), vr: rnd(-0.2, 0.2), s: rnd(5, 8), c: pick(COLORS), life: rnd(160, 240) });
        }
        kick();
      },
      clear() { parts = []; }
    };
  })();

  // ------------------------------------------------------------------ screens
  let current = 'cover';
  function show(id) {
    document.querySelectorAll('.screen').forEach((s) => s.classList.toggle('on', s.id === id));
    current = id;
  }
  function refreshSoundIcons() {
    ['#sndBtn1', '#sndBtn2'].forEach((s) => { $(s).textContent = Snd.on ? '🔊' : '🔇'; });
    $('#musBtn1').style.opacity = Snd.music ? 1 : 0.45;
  }
  function onTap(el, fn) {
    el.addEventListener('click', (e) => { Snd.init(); fn(e); });
  }

  // cover
  onTap($('#playBtn'), () => {
    Snd.tap(); Snd.trumpet(0.05);
    say('Let\'s build animal puzzles with Ellie!');
    buildSelect(); show('select');
  });
  onTap($('#sndBtn1'), () => { Snd.toggle(); refreshSoundIcons(); Snd.tap(); });
  onTap($('#sndBtn2'), () => { Snd.toggle(); refreshSoundIcons(); Snd.tap(); });
  onTap($('#musBtn1'), () => { Snd.toggleMusic(); refreshSoundIcons(); Snd.tap(); });
  onTap($('#homeBtn1'), () => { Snd.tap(); show('cover'); });
  refreshSoundIcons();

  // select
  let level = store.get('level', 0);
  function stars(n) {
    let s = '';
    for (let i = 0; i < 3; i++) s += i < n ? '★' : '<span class="off">★</span>';
    return s;
  }
  function buildSelect() {
    const lv = $('#levels'); lv.innerHTML = '';
    LEVELS.forEach((L, i) => {
      const b = document.createElement('button');
      b.className = 'lvl' + (i === level ? ' sel' : '');
      b.innerHTML = '<b>' + L.icon + '</b>' + L.label + '<span style="font-size:13px;opacity:.7">' + (L.c * L.r) + ' pieces</span>';
      onTap(b, () => { level = i; store.set('level', i); Snd.tap(); say(L.label); buildSelect(); });
      lv.appendChild(b);
    });
    const g = $('#grid'); g.innerHTML = '';
    const best = store.get('best', {});
    PUZZLES.forEach((p, i) => {
      const c = document.createElement('button');
      c.className = 'card'; c.style.animationDelay = (i * 0.04) + 's';
      c.innerHTML = '<img alt="" src="' + urls[p.id] + '"><div>' + p.name + '</div><div class="stars">' + stars(best[p.id] || 0) + '</div>';
      onTap(c, () => { Snd.tap(); say(p.name); startPuzzle(i); });
      g.appendChild(c);
    });
  }

  // ------------------------------------------------------------------ puzzle engine
  const play = $('#play'), board = $('#board'), tray = $('#tray'), piecesEl = $('#pieces');
  const mascot = $('#mascot'), bubble = $('#bubble'), ghost = $('#ghostFull');
  mascot.innerHTML = '<img src="' + ellieURL + '" style="width:100%;height:100%" alt="">';
  const hitCtx = document.createElement('canvas').getContext('2d');
  let st = null;

  function edgeTo(path, x0, y0, x1, y1, d, T) {
    if (!d) { path.lineTo(x1, y1); return; }
    const dx = x1 - x0, dy = y1 - y0, L = Math.hypot(dx, dy);
    const ux = dx / L, uy = dy / L, nx = dy / L, ny = -dx / L;
    const P = (a, b) => [x0 + ux * a * L + nx * b * T * d, y0 + uy * a * L + ny * b * T * d];
    path.lineTo(...P(0.34, 0));
    path.bezierCurveTo(...P(0.40, 0.08), ...P(0.28, 0.92), ...P(0.50, 0.96));
    path.bezierCurveTo(...P(0.72, 0.92), ...P(0.60, 0.08), ...P(0.66, 0));
    path.lineTo(x1, y1);
  }
  function piecePath(p, w, h, T) {
    const path = new Path2D();
    path.moveTo(0, 0);
    edgeTo(path, 0, 0, w, 0, p.e[0], T);
    edgeTo(path, w, 0, w, h, p.e[1], T);
    edgeTo(path, w, h, 0, h, p.e[2], T);
    edgeTo(path, 0, h, 0, 0, p.e[3], T);
    path.closePath();
    return path;
  }

  function startPuzzle(idx) {
    const L = LEVELS[level];
    const cols = L.c, rows = L.r;
    const H = [], V = [];
    for (let r = 0; r < rows; r++) { H.push([]); V.push([]); for (let c = 0; c < cols; c++) { H[r].push(Math.random() < 0.5 ? 1 : -1); V[r].push(Math.random() < 0.5 ? 1 : -1); } }
    const pieces = [];
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
      pieces.push({
        r, c, placed: false,
        e: [r === 0 ? 0 : -H[r - 1][c], c === cols - 1 ? 0 : V[r][c], r === rows - 1 ? 0 : H[r][c], c === 0 ? 0 : -V[r][c - 1]]
      });
    }
    st = { idx, cols, rows, pieces, placedCount: 0, done: false, drag: null, scattered: false, puz: PUZZLES[idx] };
    $('#pname').textContent = st.puz.name;
    $('#prog i').style.width = '0%';
    $('#win').classList.remove('on');
    FX.clear();
    show('puzzle');
    loadImg(st.puz.id).then((img) => {
      st.img = img;
      layout();
      setTimeout(() => { talk('Let\'s build ' + st.puz.full + '!', true); }, 350);
    });
  }

  function layout() {
    if (!st || !st.img) return;
    const W = play.clientWidth, Hh = play.clientHeight, pad = 12;
    const landscape = W > Hh * 1.15;
    let bw, bh, bx, by, tr;
    if (landscape) {
      bh = Math.min(Hh - pad * 2, (W * 0.56) * 3 / 4); bw = bh * 4 / 3;
      bx = pad + 4; by = (Hh - bh) / 2;
      tr = { x: bx + bw + pad * 2, y: pad, w: W - (bx + bw + pad * 3), h: Hh - pad * 2 };
    } else {
      bw = Math.min(W - pad * 2 - 8, (Hh * 0.5) * 4 / 3); bh = bw * 3 / 4;
      bx = (W - bw) / 2; by = pad;
      tr = { x: pad, y: by + bh + pad * 2, w: W - pad * 2, h: Hh - (by + bh + pad * 3) };
    }
    const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
    const pw = bw / st.cols, ph = bh / st.rows, T = Math.min(pw, ph) * 0.24, m = Math.ceil(T * 1.05 + 4);
    Object.assign(st, { W, H: Hh, bx, by, bw, bh, pw, ph, T, m, tr, dpr, landscape });

    // full-res image
    const full = document.createElement('canvas');
    full.width = Math.round(bw * dpr); full.height = Math.round(bh * dpr);
    full.getContext('2d').drawImage(st.img, 0, 0, full.width, full.height);
    st.full = full;

    // board
    Object.assign(board.style, { left: bx + 'px', top: by + 'px', width: bw + 'px', height: bh + 'px' });
    board.width = full.width; board.height = full.height;
    Object.assign(ghost.style, { left: bx + 'px', top: by + 'px', width: bw + 'px', height: bh + 'px' });
    ghost.src = urls[st.puz.id];
    Object.assign(tray.style, { left: tr.x + 'px', top: tr.y + 'px', width: tr.w + 'px', height: tr.h + 'px' });

    // pieces
    piecesEl.innerHTML = '';
    st.pieces.forEach((p) => {
      p.w = pw; p.h = ph; p.tx = bx + p.c * pw; p.ty = by + p.r * ph;
      p.path = piecePath(p, pw, ph, T);
      const cv = document.createElement('canvas');
      cv.className = 'piece';
      cv.width = Math.ceil((pw + m * 2) * dpr); cv.height = Math.ceil((ph + m * 2) * dpr);
      cv.style.width = (pw + m * 2) + 'px'; cv.style.height = (ph + m * 2) + 'px';
      const g = cv.getContext('2d');
      g.scale(dpr, dpr); g.translate(m, m);
      g.save(); g.clip(p.path);
      g.drawImage(full, 0, 0, full.width, full.height, -p.c * pw, -p.r * ph, bw, bh);
      g.restore();
      g.lineJoin = 'round';
      g.lineWidth = 3; g.strokeStyle = 'rgba(255,255,255,.9)'; g.stroke(p.path);
      g.lineWidth = 1.2; g.strokeStyle = 'rgba(40,30,70,.35)'; g.stroke(p.path);
      p.el = cv; p.scale = 1;
      piecesEl.appendChild(cv);
    });
    // stacking: placed first (bottom)
    st.pieces.filter((p) => p.placed).forEach((p) => { p.x = p.tx; p.y = p.ty; p.el.classList.add('placed'); piecesEl.insertBefore(p.el, piecesEl.firstChild); });
    scatter(st.pieces.filter((p) => !p.placed), !st.scattered);
    st.scattered = true;
    st.pieces.forEach(draw);
    drawBoard();

    // mascot
    const ms = Math.max(70, Math.min(110, Math.min(W, Hh) * 0.2));
    Object.assign(mascot.style, { width: ms + 'px', height: ms + 'px', left: (W - ms - 6) + 'px', top: (80 + Hh - ms - 6) + 'px', zIndex: 5 });
    piecesEl.style.position = 'absolute'; piecesEl.style.inset = '0'; piecesEl.style.zIndex = 10;
  }

  function scatter(list, animateIn) {
    const tr = st.tr, n = list.length;
    if (!n) return;
    const pw = st.pw, ph = st.ph;
    // choose grid that best fits tray aspect
    let best = null;
    for (let cols = 1; cols <= n; cols++) {
      const rows = Math.ceil(n / cols), cw = tr.w / cols, ch = tr.h / rows;
      const s = Math.min(cw / pw, ch / ph);
      if (!best || s > best.s) best = { cols, rows, cw, ch, s };
    }
    const cells = [];
    for (let i = 0; i < best.cols * best.rows; i++) cells.push(i);
    cells.sort(() => Math.random() - 0.5);
    list.slice().sort(() => Math.random() - 0.5).forEach((p, i) => {
      const cell = cells[i], cc = cell % best.cols, rr = (cell / best.cols) | 0;
      let cx = tr.x + (cc + 0.5) * best.cw + rnd(-0.12, 0.12) * best.cw;
      let cy = tr.y + (rr + 0.5) * best.ch + rnd(-0.12, 0.12) * best.ch;
      let x = cx - pw / 2, y = cy - ph / 2;
      x = Math.max(tr.x + 2, Math.min(tr.x + tr.w - pw - 2, x));
      y = Math.max(tr.y + 2, Math.min(tr.y + tr.h - ph - 2, y));
      if (animateIn) {
        p.x = p.tx; p.y = p.ty; draw(p);
        const fx = x, fy = y;
        setTimeout(() => tween(p, fx, fy, 520, easeOutBack), 650 + i * 60);
      } else { p.x = x; p.y = y; }
    });
    if (animateIn) setTimeout(() => Snd.whoosh(), 650);
  }

  function draw(p) {
    p.el.style.transform = 'translate3d(' + (p.x - st.m) + 'px,' + (p.y - st.m) + 'px,0) scale(' + p.scale + ')';
  }

  function drawBoard(highlight) {
    const g = board.getContext('2d'), d = st.dpr;
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.clearRect(0, 0, board.width, board.height);
    g.fillStyle = '#ffffff'; g.fillRect(0, 0, board.width, board.height);
    g.globalAlpha = 0.22; g.drawImage(st.full, 0, 0); g.globalAlpha = 1;
    g.setTransform(d, 0, 0, d, 0, 0);
    st.pieces.forEach((p) => {
      g.save(); g.translate(p.c * st.pw, p.r * st.ph);
      if (p === highlight) { g.fillStyle = 'rgba(255,216,77,.75)'; g.fill(p.path); }
      g.setLineDash([6, 5]); g.lineWidth = 1.6; g.strokeStyle = 'rgba(76,150,220,.55)'; g.stroke(p.path);
      g.restore();
    });
  }

  const easeOutBack = (t) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
  const easeOut = (t) => 1 - Math.pow(1 - t, 3);
  function tween(p, x, y, ms, ease, done, scaleTo) {
    const x0 = p.x, y0 = p.y, s0 = p.scale, s1 = scaleTo == null ? p.scale : scaleTo, t0 = performance.now();
    p.anim = (p.anim || 0) + 1; const my = p.anim;
    (function f(now) {
      if (p.anim !== my) return;
      const t = Math.min(1, (now - t0) / ms), k = (ease || easeOut)(t);
      p.x = x0 + (x - x0) * k; p.y = y0 + (y - y0) * k; p.scale = s0 + (s1 - s0) * Math.min(1, t * 1.5);
      draw(p);
      if (t < 1) requestAnimationFrame(f); else if (done) done();
    })(t0);
  }

  function local(e) {
    const r = play.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }
  function hitTest(pt) {
    const els = Array.from(piecesEl.children);
    let nearest = null, nd = Infinity;
    for (let i = els.length - 1; i >= 0; i--) {
      const p = st.pieces.find((q) => q.el === els[i]);
      if (!p || p.placed) continue;
      const lx = pt.x - p.x, ly = pt.y - p.y;
      if (hitCtx.isPointInPath(p.path, lx, ly)) return p;
      const dd = Math.hypot(lx - p.w / 2, ly - p.h / 2);
      if (dd < nd) { nd = dd; nearest = p; }
    }
    // forgiving touch for little fingers
    if (nearest && nd < Math.max(st.pw, st.ph) * 0.62) return nearest;
    return null;
  }

  play.addEventListener('pointerdown', (e) => {
    Snd.init();
    if (!st || st.done || st.drag || !st.full) return;
    const pt = local(e), p = hitTest(pt);
    if (!p) return;
    e.preventDefault();
    p.anim = (p.anim || 0) + 1; // cancel tweens
    st.drag = { p, id: e.pointerId, ox: pt.x - p.x, oy: pt.y - p.y };
    try { play.setPointerCapture(e.pointerId); } catch (err) { }
    piecesEl.appendChild(p.el);
    p.el.classList.add('lift');
    p.scale = 1.08; draw(p);
    Snd.pick(); buzz(8);
  });
  play.addEventListener('pointermove', (e) => {
    const d = st && st.drag;
    if (!d || d.id !== e.pointerId) return;
    e.preventDefault();
    const pt = local(e), p = d.p;
    p.x = Math.max(-p.w * 0.3, Math.min(st.W - p.w * 0.7, pt.x - d.ox));
    p.y = Math.max(-p.h * 0.3, Math.min(st.H - p.h * 0.7, pt.y - d.oy));
    draw(p);
  });
  function endDrag(e) {
    const d = st && st.drag;
    if (!d || d.id !== e.pointerId) return;
    st.drag = null;
    const p = d.p;
    p.el.classList.remove('lift');
    const dist = Math.hypot(p.x - p.tx, p.y - p.ty);
    if (dist < Math.max(st.pw, st.ph) * 0.38) {
      p.placed = true;
      tween(p, p.tx, p.ty, 160, easeOut, () => placed(p), 1);
    } else {
      Snd.drop();
      // keep fully on screen
      const nx = Math.max(0, Math.min(st.W - p.w, p.x)), ny = Math.max(0, Math.min(st.H - p.h, p.y));
      tween(p, nx, ny, 220, easeOutBack, null, 1);
    }
  }
  play.addEventListener('pointerup', endDrag);
  play.addEventListener('pointercancel', endDrag);

  function placed(p) {
    p.el.classList.add('placed');
    piecesEl.insertBefore(p.el, piecesEl.firstChild);
    st.placedCount++;
    const total = st.pieces.length;
    $('#prog i').style.width = (st.placedCount / total * 100) + '%';
    const r = play.getBoundingClientRect();
    FX.sparkle(r.left + p.x + p.w / 2, r.top + p.y + p.h / 2, 18);
    Snd.snap(); buzz(25);
    mascot.classList.remove('wiggle'); void mascot.offsetWidth; mascot.classList.add('wiggle');
    if (st.placedCount === total) { complete(); return; }
    const msg = pick(PRAISE);
    talk(msg, st.placedCount % 3 === 1);
  }

  let bubbleTimer = null;
  function talk(text, speak) {
    bubble.textContent = text;
    const mr = mascot.getBoundingClientRect();
    bubble.classList.add('show');
    const bw = bubble.offsetWidth;
    bubble.style.left = Math.max(8, mr.left - bw + 18) + 'px';
    bubble.style.top = Math.max(80, mr.top - 30) + 'px';
    clearTimeout(bubbleTimer);
    bubbleTimer = setTimeout(() => bubble.classList.remove('show'), 1800);
    if (speak) say(text);
  }

  onTap($('#hintBtn'), () => {
    if (!st || st.done) return;
    Snd.sparkle();
    const left = st.pieces.filter((p) => !p.placed);
    if (!left.length) return;
    const p = pick(left);
    ghost.style.opacity = 0.75;
    drawBoard(p);
    piecesEl.appendChild(p.el);
    let n = 0;
    const pulse = () => {
      if (n++ >= 3 || p.placed || (st.drag && st.drag.p === p)) { if (!p.placed && !(st.drag && st.drag.p === p)) { p.scale = 1; draw(p); } return; }
      tween(p, p.x, p.y, 220, easeOut, () => tween(p, p.x, p.y, 220, easeOut, pulse, 1), 1.18);
    };
    pulse();
    talk('This piece goes here!', true);
    setTimeout(() => { ghost.style.opacity = 0; }, 1300);
    setTimeout(() => { if (st && !st.done) drawBoard(); }, 2200);
  });

  function complete() {
    st.done = true;
    const best = store.get('best', {});
    const earned = level + 1;
    best[st.puz.id] = Math.max(best[st.puz.id] || 0, earned);
    store.set('best', best);
    Snd.sparkle();
    ghost.style.opacity = 1;
    setTimeout(() => {
      const w = $('#win');
      $('#winImg img').src = urls[st.puz.id];
      $('#dancer').src = ellieURL; $('#dancer2').src = ellieHatURL;
      let s = '';
      for (let i = 0; i < 3; i++) s += '<span style="animation-delay:' + (0.45 + i * 0.25) + 's;color:' + (i < earned ? '#ffc93c' : '#fff') + ';text-shadow:0 3px 0 ' + (i < earned ? '#d39b16' : '#e0c9d6') + '">★</span>';
      $('#winStars').innerHTML = s;
      $('#winFact').textContent = '🐘 ' + st.puz.fact;
      w.classList.add('on');
      celebrate();
      say('Hooray! You built ' + st.puz.full + '! ' + st.puz.say);
      setTimeout(() => say(st.puz.fact), 3600);
    }, 650);
  }

  function celebrate() {
    Snd.fanfare();
    Snd.trumpet(1.6);
    buzz(60);
    FX.confetti(innerWidth * 0.2, innerHeight, 70, 0.5);
    FX.confetti(innerWidth * 0.8, innerHeight, 70, 0.5);
    setTimeout(() => { FX.confetti(innerWidth / 2, innerHeight, 90, 0.7); }, 450);
    setTimeout(() => FX.rain(90), 900);
    const colors = ['#ff6fa3', '#ffd84d', '#4cd27a', '#4cb8f0', '#b07cff', '#ff8a3d'];
    for (let i = 0; i < 10; i++) {
      const b = document.createElement('div');
      b.className = 'balloon';
      b.style.left = rnd(2, 90) + 'vw';
      b.style.background = colors[i % colors.length];
      b.style.setProperty('--sway', rnd(-60, 60) + 'px');
      b.style.animationDuration = rnd(4.5, 7.5) + 's';
      b.style.animationDelay = rnd(0, 1.6) + 's';
      document.body.appendChild(b);
      setTimeout(() => b.remove(), 9500);
    }
  }

  function goSelect() { stopSpeech(); $('#win').classList.remove('on'); FX.clear(); buildSelect(); show('select'); }
  onTap($('#backBtn'), () => { Snd.tap(); goSelect(); });
  onTap($('#homeBtn2'), () => { Snd.tap(); goSelect(); });
  onTap($('#againBtn'), () => { Snd.tap(); stopSpeech(); startPuzzle(st.idx); });
  onTap($('#nextBtn'), () => { Snd.tap(); stopSpeech(); startPuzzle((st.idx + 1) % PUZZLES.length); });

  // relayout on rotate
  let rz = null;
  addEventListener('resize', () => {
    clearTimeout(rz);
    rz = setTimeout(() => { if (current === 'puzzle' && st && !st.drag) layout(); }, 160);
  });

  // Android hooks
  window.onAndroidBack = function () {
    if ($('#win').classList.contains('on')) { goSelect(); return true; }
    if (current === 'puzzle') { goSelect(); return true; }
    if (current === 'select') { show('cover'); return true; }
    return false;
  };
  window.onAndroidPause = function () { Snd.suspend(); stopSpeech(); };
  window.onAndroidResume = function () { Snd.resume(); };
  document.addEventListener('visibilitychange', () => { if (document.hidden) Snd.suspend(); else Snd.resume(); });
  // block long-press menus / pinch zoom
  document.addEventListener('contextmenu', (e) => e.preventDefault());
  document.addEventListener('gesturestart', (e) => e.preventDefault());

  // preload images
  PUZZLES.forEach((p) => loadImg(p.id));
  window.__game = { startPuzzle, get st() { return st; }, PUZZLES };
})();
