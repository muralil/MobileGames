/* Original cartoon artwork for Ellie's Animal Puzzles — all drawn as SVG (400 x 300). */
(function () {
  const OL = '#3b3550'; // outline colour
  const sw = 3;

  function svg(inner, defs) {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" width="800" height="600">' +
      '<defs>' + (defs || '') + '</defs>' + inner + '</svg>';
  }

  // ---------- scenery ----------
  function sky(id, top, bottom) {
    return '<linearGradient id="' + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + top +
      '"/><stop offset="1" stop-color="' + bottom + '"/></linearGradient>';
  }
  function cloud(x, y, s) {
    return '<g transform="translate(' + x + ',' + y + ') scale(' + s + ')" fill="#fff" opacity=".95">' +
      '<ellipse cx="0" cy="0" rx="26" ry="15"/><ellipse cx="22" cy="-8" rx="20" ry="16"/>' +
      '<ellipse cx="42" cy="2" rx="22" ry="13"/><ellipse cx="18" cy="6" rx="30" ry="11"/></g>';
  }
  function sun(x, y, r) {
    let rays = '';
    for (let i = 0; i < 12; i++) {
      const a = i * Math.PI / 6;
      rays += '<line x1="' + (x + Math.cos(a) * (r + 6)) + '" y1="' + (y + Math.sin(a) * (r + 6)) + '" x2="' +
        (x + Math.cos(a) * (r + 16)) + '" y2="' + (y + Math.sin(a) * (r + 16)) +
        '" stroke="#ffc93c" stroke-width="5" stroke-linecap="round"/>';
    }
    return rays + '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="#ffd84d" stroke="#f4a62a" stroke-width="3"/>' +
      '<circle cx="' + (x - 6) + '" cy="' + (y - 3) + '" r="2.5" fill="#6b4a1a"/><circle cx="' + (x + 6) + '" cy="' + (y - 3) +
      '" r="2.5" fill="#6b4a1a"/><path d="M' + (x - 7) + ' ' + (y + 5) + ' q7 6 14 0" stroke="#6b4a1a" stroke-width="2.5" fill="none" stroke-linecap="round"/>';
  }
  function flowers(list) {
    return list.map(function (f) {
      const [x, y, c] = f;
      return '<g transform="translate(' + x + ',' + y + ')"><line x1="0" y1="0" x2="0" y2="12" stroke="#4f9a3a" stroke-width="2"/>' +
        '<circle cx="-4" cy="-2" r="4" fill="' + c + '"/><circle cx="4" cy="-2" r="4" fill="' + c + '"/><circle cx="0" cy="-6" r="4" fill="' + c +
        '"/><circle cx="0" cy="2" r="4" fill="' + c + '"/><circle cx="0" cy="-2" r="3" fill="#ffe066"/></g>';
    }).join('');
  }
  function grassTufts(n, y0, seed) {
    let s = '', r = seed || 7;
    function rnd() { r = (r * 9301 + 49297) % 233280; return r / 233280; }
    for (let i = 0; i < n; i++) {
      const x = 10 + rnd() * 380, y = y0 + rnd() * (290 - y0);
      s += '<path d="M' + x + ' ' + y + ' l-4 -10 M' + x + ' ' + y + ' l0 -12 M' + x + ' ' + y + ' l4 -10" stroke="#3f8f3a" stroke-width="2" stroke-linecap="round" opacity=".55"/>';
    }
    return s;
  }
  function savanna(id) {
    return '<rect width="400" height="300" fill="url(#' + id + ')"/>' + sun(340, 52, 22) + cloud(40, 40, 1) + cloud(200, 30, .8) +
      '<path d="M0 190 Q100 150 200 185 T400 175 V300 H0Z" fill="#b6df7a"/>' +
      '<path d="M0 215 Q120 190 250 215 T400 205 V300 H0Z" fill="#8fcf5c"/>' +
      grassTufts(26, 220, 3);
  }
  function acacia(x, y, s) {
    return '<g transform="translate(' + x + ',' + y + ') scale(' + s + ')"><path d="M-4 0 L-2 -45 L-18 -62 M-2 -45 L14 -66 M-2 -45 L-2 -64" stroke="#7a5230" stroke-width="7" fill="none" stroke-linecap="round"/>' +
      '<ellipse cx="-2" cy="-72" rx="48" ry="14" fill="#5aa54a" stroke="#3f7d35" stroke-width="2"/></g>';
  }
  function palm(x, y, s) {
    return '<g transform="translate(' + x + ',' + y + ') scale(' + s + ')">' +
      '<path d="M0 0 Q6 -40 -2 -80" stroke="#9b6b3c" stroke-width="10" fill="none" stroke-linecap="round"/>' +
      '<path d="M-2 -80 q-30 -10 -48 8 q22 -4 48 -8z M-2 -80 q30 -12 50 6 q-24 -4 -50 -6z M-2 -80 q-12 -26 -38 -30 q20 10 38 30z M-2 -80 q14 -28 40 -28 q-22 10 -40 28z" fill="#45a63e" stroke="#2f7a2f" stroke-width="2"/>' +
      '<circle cx="-6" cy="-76" r="5" fill="#7a4a22"/><circle cx="3" cy="-74" r="5" fill="#7a4a22"/></g>';
  }
  function eye(x, y, r, look) {
    const lx = (look || 0) * r * 0.25;
    return '<ellipse cx="' + x + '" cy="' + y + '" rx="' + r + '" ry="' + (r * 1.15) + '" fill="#fff" stroke="' + OL + '" stroke-width="2"/>' +
      '<circle cx="' + (x + lx) + '" cy="' + (y + r * 0.15) + '" r="' + (r * 0.58) + '" fill="#2b2238"/>' +
      '<circle cx="' + (x + lx + r * 0.22) + '" cy="' + (y - r * 0.12) + '" r="' + (r * 0.22) + '" fill="#fff"/>';
  }
  function cheek(x, y, r) { return '<ellipse cx="' + x + '" cy="' + y + '" rx="' + r + '" ry="' + (r * .7) + '" fill="#ff8fa3" opacity=".55"/>'; }

  // ---------- animals ----------
  function elephant(x, y, s, opt) {
    opt = opt || {};
    const c = opt.color || '#a9b4c2', d = opt.dark || '#8a96a6', ear = '#f6b8c6';
    const flip = opt.flip ? -1 : 1;
    return '<g transform="translate(' + x + ',' + y + ') scale(' + (s * flip) + ',' + s + ')" stroke="' + OL + '" stroke-width="' + sw + '" stroke-linejoin="round">' +
      // tail
      '<path d="M78 -6 q22 6 18 34" fill="none" stroke-linecap="round"/><path d="M92 26 l10 8 l-12 2z" fill="' + OL + '"/>' +
      // back legs
      '<rect x="40" y="10" width="30" height="52" rx="12" fill="' + d + '"/>' +
      '<rect x="-2" y="14" width="30" height="48" rx="12" fill="' + d + '"/>' +
      // body
      '<ellipse cx="22" cy="0" rx="66" ry="46" fill="' + c + '"/>' +
      // front legs
      '<rect x="-30" y="14" width="30" height="50" rx="12" fill="' + c + '"/>' +
      '<rect x="14" y="18" width="30" height="46" rx="12" fill="' + c + '"/>' +
      '<g stroke="none" fill="#f4efe6"><ellipse cx="-22" cy="60" rx="5" ry="3.5"/><ellipse cx="-12" cy="61" rx="5" ry="3.5"/><ellipse cx="22" cy="60" rx="5" ry="3.5"/><ellipse cx="32" cy="61" rx="5" ry="3.5"/></g>' +
      // ear (behind head)
      '<path d="M-30 -78 C10 -92 26 -40 8 -10 C-4 10 -30 4 -36 -14 Z" fill="' + c + '"/>' +
      '<path d="M-24 -66 C2 -76 14 -40 2 -20 C-6 -6 -22 -8 -26 -20 Z" fill="' + ear + '" stroke="none"/>' +
      // head
      '<circle cx="-52" cy="-40" r="44" fill="' + c + '"/>' +
      // trunk
      '<path d="M-84 -28 C-104 -10 -104 22 -92 38 C-86 46 -74 44 -74 36 C-74 28 -84 26 -84 16 C-84 0 -70 -10 -64 -14 Z" fill="' + c + '"/>' +
      '<path d="M-90 4 q6 2 10 0 M-91 16 q6 2 10 0 M-88 28 q5 2 9 0" fill="none" stroke-width="2" stroke-linecap="round"/>' +
      // tusk
      '<path d="M-66 -10 q-6 14 -16 16 q8 -10 8 -18z" fill="#fffaf0" stroke-width="2"/>' +
      '</g>' +
      // face (no flip of eyes needed since symmetric drawing)
      '<g transform="translate(' + x + ',' + y + ') scale(' + (s * flip) + ',' + s + ')">' +
      eye(-62, -50, 9, -0.5) + eye(-36, -52, 8, -0.5) +
      cheek(-30, -28, 7) + cheek(-80, -24, 6) +
      '<path d="M-58 -16 q12 10 24 0" stroke="' + OL + '" stroke-width="3" fill="#ff7b8f" stroke-linecap="round"/>' +
      (opt.bow ? '<g transform="translate(-40,-84) rotate(-12)"><path d="M0 0 l-16 -10 v20z M0 0 l16 -10 v20z" fill="#ff5f8f" stroke="' + OL + '" stroke-width="2"/><circle r="5" fill="#ff8fb0" stroke="' + OL + '" stroke-width="2"/></g>' : '') +
      (opt.hat ? '<g transform="translate(-52,-84)"><path d="M-14 0 L0 -32 L14 0Z" fill="#4cc9f0" stroke="' + OL + '" stroke-width="2"/><circle cx="0" cy="-34" r="5" fill="#ffd84d" stroke="' + OL + '" stroke-width="2"/><path d="M-9 -10 l18 0 M-5 -20 l10 0" stroke="#fff" stroke-width="3"/></g>' : '') +
      '</g>';
  }

  function lion(x, y, s) {
    let mane = '';
    for (let i = 0; i < 16; i++) {
      const a = i * Math.PI / 8;
      mane += '<circle cx="' + (Math.cos(a) * 52).toFixed(1) + '" cy="' + (Math.sin(a) * 52 - 40).toFixed(1) + '" r="22" fill="' + (i % 2 ? '#e0762b' : '#c95f1f') + '"/>';
    }
    return '<g transform="translate(' + x + ',' + y + ') scale(' + s + ')" stroke="' + OL + '" stroke-width="' + sw + '">' +
      '<path d="M60 30 q40 -10 46 -40" fill="none" stroke-linecap="round"/><ellipse cx="108" cy="-14" rx="9" ry="12" fill="#c95f1f"/>' +
      '<ellipse cx="30" cy="38" rx="62" ry="38" fill="#f3b849"/>' +
      '<rect x="-14" y="44" width="26" height="36" rx="11" fill="#f3b849"/><rect x="50" y="44" width="26" height="36" rx="11" fill="#f3b849"/>' +
      '<g stroke="' + OL + '">' + mane + '</g>' +
      '<circle cx="0" cy="-40" r="46" fill="#f7c55a"/>' +
      '<circle cx="-34" cy="-80" r="12" fill="#f7c55a"/><circle cx="34" cy="-80" r="12" fill="#f7c55a"/>' +
      '<circle cx="-34" cy="-80" r="6" fill="#f29a64" stroke="none"/><circle cx="34" cy="-80" r="6" fill="#f29a64" stroke="none"/>' +
      '<ellipse cx="0" cy="-18" rx="24" ry="18" fill="#fde3a7"/>' +
      '<path d="M-9 -28 h18 l-9 10z" fill="#8a4b2f" stroke-width="2"/>' +
      '<path d="M0 -18 v6 M0 -12 q-8 8 -14 2 M0 -12 q8 8 14 2" fill="none" stroke-width="2.5" stroke-linecap="round"/>' +
      '</g><g transform="translate(' + x + ',' + y + ') scale(' + s + ')">' + eye(-16, -48, 8) + eye(16, -48, 8) + cheek(-28, -24, 6) + cheek(28, -24, 6) + '</g>';
  }

  function giraffe(x, y, s) {
    const c = '#f7c948', sp = '#d9822b';
    return '<g transform="translate(' + x + ',' + y + ') scale(' + s + ')" stroke="' + OL + '" stroke-width="' + sw + '" stroke-linejoin="round">' +
      '<path d="M58 0 q20 10 16 36" fill="none"/><path d="M70 34 l8 10 l-12 0z" fill="' + OL + '"/>' +
      '<rect x="-30" y="10" width="16" height="66" rx="7" fill="' + c + '"/><rect x="34" y="10" width="16" height="66" rx="7" fill="' + c + '"/>' +
      '<ellipse cx="14" cy="0" rx="52" ry="34" fill="' + c + '"/>' +
      '<rect x="-12" y="12" width="16" height="66" rx="7" fill="' + c + '"/><rect x="50" y="12" width="16" height="66" rx="7" fill="' + c + '"/>' +
      '<path d="M-30 -14 L-44 -128 L-16 -132 L-4 -18Z" fill="' + c + '"/>' +
      '<g fill="' + sp + '" stroke="none"><circle cx="0" cy="-8" r="9"/><circle cx="26" cy="-14" r="8"/><circle cx="40" cy="8" r="9"/><circle cx="10" cy="14" r="7"/><circle cx="-34" cy="-46" r="7"/><circle cx="-28" cy="-80" r="6"/><circle cx="-36" cy="-108" r="6"/><circle cx="-18" cy="-60" r="5"/></g>' +
      '<path d="M-44 -150 l-4 -16 M-26 -152 l2 -16" stroke-width="4" stroke-linecap="round"/><circle cx="-48" cy="-168" r="5" fill="' + sp + '"/><circle cx="-24" cy="-170" r="5" fill="' + sp + '"/>' +
      '<ellipse cx="-60" cy="-144" rx="12" ry="6" fill="' + c + '" transform="rotate(-20 -60 -144)"/>' +
      '<ellipse cx="-34" cy="-136" rx="30" ry="22" fill="' + c + '"/>' +
      '<ellipse cx="-56" cy="-126" rx="18" ry="13" fill="#f9dd8a"/>' +
      '<circle cx="-62" cy="-128" r="2.5" fill="' + OL + '" stroke="none"/><circle cx="-52" cy="-128" r="2.5" fill="' + OL + '" stroke="none"/>' +
      '<path d="M-62 -118 q6 5 12 0" fill="none" stroke-width="2.5" stroke-linecap="round"/>' +
      '</g><g transform="translate(' + x + ',' + y + ') scale(' + s + ')">' + eye(-36, -144, 7, -0.4) + eye(-18, -144, 6, -0.4) + cheek(-20, -126, 5) + '</g>';
  }

  function monkey(x, y, s) {
    const c = '#9a6236', f = '#f3cfa0';
    return '<g transform="translate(' + x + ',' + y + ') scale(' + s + ')" stroke="' + OL + '" stroke-width="' + sw + '" stroke-linejoin="round">' +
      '<path d="M30 40 C80 50 80 -10 56 -14 C44 -16 44 0 54 0" fill="none" stroke="' + c + '" stroke-width="10" stroke-linecap="round"/>' +
      '<path d="M30 40 C80 50 80 -10 56 -14 C44 -16 44 0 54 0" fill="none" stroke-width="2" opacity=".0"/>' +
      '<ellipse cx="0" cy="40" rx="40" ry="44" fill="' + c + '"/>' +
      '<ellipse cx="0" cy="48" rx="24" ry="28" fill="' + f + '"/>' +
      '<ellipse cx="-26" cy="84" rx="18" ry="10" fill="' + c + '"/><ellipse cx="26" cy="84" rx="18" ry="10" fill="' + c + '"/>' +
      // arm holding banana
      '<path d="M30 20 Q74 14 80 -12" fill="none" stroke="' + c + '" stroke-width="16" stroke-linecap="round"/>' +
      '<path d="M72 -22 C92 -42 112 -22 106 4 C102 -12 90 -22 72 -22Z" fill="#ffe14d"/><path d="M72 -22 l-6 -4" stroke-width="4" stroke-linecap="round"/>' +
      '<circle cx="80" cy="-12" r="9" fill="' + f + '"/>' +
      '<path d="M-30 20 Q-50 40 -36 60" fill="none" stroke="' + c + '" stroke-width="16" stroke-linecap="round"/>' +
      '<circle cx="-50" cy="-36" r="18" fill="' + c + '"/><circle cx="50" cy="-36" r="18" fill="' + c + '" opacity="0"/>' +
      '<circle cx="-50" cy="-36" r="10" fill="' + f + '" stroke="none"/>' +
      '<circle cx="0" cy="-36" r="44" fill="' + c + '"/>' +
      '<circle cx="44" cy="-46" r="16" fill="' + c + '"/><circle cx="44" cy="-46" r="8" fill="' + f + '" stroke="none"/>' +
      '<path d="M-30 -40 C-30 -70 -4 -66 0 -52 C4 -66 30 -70 30 -40 C40 -10 20 6 0 6 C-20 6 -40 -10 -30 -40Z" fill="' + f + '"/>' +
      '<ellipse cx="0" cy="-14" rx="8" ry="4" fill="#7a4a2a" stroke="none"/>' +
      '<path d="M-12 -6 q12 10 24 0" fill="#ff7b8f" stroke-width="2.5" stroke-linecap="round"/>' +
      '</g><g transform="translate(' + x + ',' + y + ') scale(' + s + ')">' + eye(-12, -42, 8) + eye(12, -42, 8) + cheek(-22, -20, 5) + cheek(22, -20, 5) + '</g>';
  }

  function hippo(x, y, s) {
    const c = '#b49ad6', d = '#9a80c0';
    return '<g transform="translate(' + x + ',' + y + ') scale(' + s + ')" stroke="' + OL + '" stroke-width="' + sw + '" stroke-linejoin="round">' +
      '<ellipse cx="40" cy="10" rx="78" ry="48" fill="' + c + '"/>' +
      '<circle cx="-36" cy="-66" r="11" fill="' + c + '"/><circle cx="12" cy="-66" r="11" fill="' + c + '"/>' +
      '<circle cx="-36" cy="-66" r="5" fill="#f6b8c6" stroke="none"/><circle cx="12" cy="-66" r="5" fill="#f6b8c6" stroke="none"/>' +
      '<ellipse cx="-12" cy="-30" rx="46" ry="40" fill="' + c + '"/>' +
      '<ellipse cx="-14" cy="0" rx="56" ry="32" fill="' + d + '"/>' +
      '<ellipse cx="-34" cy="-8" rx="6" ry="4" fill="' + OL + '" stroke="none"/><ellipse cx="6" cy="-8" rx="6" ry="4" fill="' + OL + '" stroke="none"/>' +
      '<path d="M-44 12 q30 20 60 0" fill="none" stroke-width="3" stroke-linecap="round"/>' +
      '<rect x="-30" y="14" width="8" height="9" rx="2" fill="#fff" stroke-width="2"/><rect x="0" y="14" width="8" height="9" rx="2" fill="#fff" stroke-width="2"/>' +
      '</g><g transform="translate(' + x + ',' + y + ') scale(' + s + ')">' + eye(-32, -44, 8) + eye(6, -44, 8) + cheek(-56, -14, 6) + cheek(32, -14, 6) + '</g>';
  }

  function panda(x, y, s) {
    return '<g transform="translate(' + x + ',' + y + ') scale(' + s + ')" stroke="' + OL + '" stroke-width="' + sw + '" stroke-linejoin="round">' +
      '<ellipse cx="0" cy="40" rx="50" ry="46" fill="#fff"/>' +
      '<ellipse cx="-32" cy="80" rx="20" ry="13" fill="#2f2b3a"/><ellipse cx="32" cy="80" rx="20" ry="13" fill="#2f2b3a"/>' +
      '<path d="M-44 6 Q-70 30 -50 52" stroke="#2f2b3a" stroke-width="22" fill="none" stroke-linecap="round"/>' +
      // bamboo held
      '<g transform="rotate(18 44 10)"><rect x="38" y="-60" width="12" height="110" rx="4" fill="#7cc35a"/><path d="M38 -24 h12 M38 12 h12" stroke-width="2"/><path d="M50 -40 q22 -12 30 -2 q-16 0 -30 2z" fill="#5aa54a" stroke-width="2"/></g>' +
      '<path d="M40 6 Q60 20 44 40" stroke="#2f2b3a" stroke-width="22" fill="none" stroke-linecap="round"/>' +
      '<circle cx="-36" cy="-72" r="16" fill="#2f2b3a"/><circle cx="36" cy="-72" r="16" fill="#2f2b3a"/>' +
      '<circle cx="0" cy="-36" r="46" fill="#fff"/>' +
      '<ellipse cx="-18" cy="-40" rx="13" ry="16" fill="#2f2b3a" transform="rotate(25 -18 -40)" stroke="none"/>' +
      '<ellipse cx="18" cy="-40" rx="13" ry="16" fill="#2f2b3a" transform="rotate(-25 18 -40)" stroke="none"/>' +
      '<ellipse cx="0" cy="-18" rx="8" ry="5" fill="#2f2b3a" stroke="none"/>' +
      '<path d="M-10 -8 q10 9 20 0" fill="none" stroke-width="2.5" stroke-linecap="round"/>' +
      '<circle cx="-16" cy="-40" r="5" fill="#fff" stroke="none"/><circle cx="16" cy="-40" r="5" fill="#fff" stroke="none"/>' +
      '<circle cx="-15" cy="-39" r="3" fill="#111" stroke="none"/><circle cx="15" cy="-39" r="3" fill="#111" stroke="none"/>' +
      '</g><g transform="translate(' + x + ',' + y + ') scale(' + s + ')">' + cheek(-30, -16, 6) + cheek(30, -16, 6) + '</g>';
  }

  function turtle(x, y, s) {
    return '<g transform="translate(' + x + ',' + y + ') scale(' + s + ')" stroke="' + OL + '" stroke-width="' + sw + '" stroke-linejoin="round">' +
      '<ellipse cx="-52" cy="30" rx="14" ry="20" fill="#9ad66a"/><ellipse cx="52" cy="30" rx="14" ry="20" fill="#9ad66a"/>' +
      '<path d="M70 14 l18 6 l-16 8z" fill="#9ad66a"/>' +
      '<ellipse cx="-80" cy="-18" rx="30" ry="26" fill="#9ad66a"/>' +
      '<path d="M-70 10 C-70 -60 70 -60 70 10 Z" fill="#3fa34d"/>' +
      '<path d="M-70 10 H70" stroke-width="4"/>' +
      '<g fill="#7bd389" stroke-width="2"><path d="M-18 -30 l18 -10 l18 10 v18 l-18 10 l-18 -10z"/><path d="M-52 -6 l14 -16 l14 6 v16 l-14 6z"/><path d="M52 -6 l-14 -16 l-14 6 v16 l14 6z"/></g>' +
      '<path d="M-92 -8 q8 7 16 1" fill="none" stroke-width="2.5" stroke-linecap="round"/>' +
      '</g><g transform="translate(' + x + ',' + y + ') scale(' + s + ')">' + eye(-90, -26, 7, -0.4) + eye(-70, -28, 6, -0.4) + cheek(-70, -10, 5) + '</g>';
  }

  function owl(x, y, s) {
    const c = '#a0724a', b = '#f2d6ae';
    return '<g transform="translate(' + x + ',' + y + ') scale(' + s + ')" stroke="' + OL + '" stroke-width="' + sw + '" stroke-linejoin="round">' +
      '<path d="M-38 -60 L-30 -92 L-12 -66Z M38 -60 L30 -92 L12 -66Z" fill="' + c + '"/>' +
      '<ellipse cx="0" cy="0" rx="50" ry="64" fill="' + c + '"/>' +
      '<ellipse cx="0" cy="22" rx="32" ry="38" fill="' + b + '"/>' +
      '<path d="M-14 8 q6 6 12 0 q6 6 12 0 M-20 24 q6 6 12 0 q6 6 12 0 q6 6 12 0 M-14 40 q6 6 12 0 q6 6 12 0" fill="none" stroke="#c99a66" stroke-width="2.5"/>' +
      '<path d="M-48 -6 Q-70 20 -42 44Z M48 -6 Q70 20 42 44Z" fill="#8a5f3b"/>' +
      '<circle cx="-20" cy="-34" r="20" fill="#fff4dc"/><circle cx="20" cy="-34" r="20" fill="#fff4dc"/>' +
      '<path d="M-6 -18 l6 12 l6 -12z" fill="#ffb84d" stroke-width="2"/>' +
      '<path d="M-16 64 l-4 8 M-10 64 l0 9 M10 64 l0 9 M16 64 l4 8" stroke="#ffb84d" stroke-width="4" stroke-linecap="round"/>' +
      '</g><g transform="translate(' + x + ',' + y + ') scale(' + s + ')">' +
      '<circle cx="-20" cy="-34" r="11" fill="#2b2238"/><circle cx="20" cy="-34" r="11" fill="#2b2238"/><circle cx="-16" cy="-38" r="4" fill="#fff"/><circle cx="24" cy="-38" r="4" fill="#fff"/></g>';
  }

  function zebra(x, y, s) {
    const st = '#2f2b3a';
    return '<g transform="translate(' + x + ',' + y + ') scale(' + s + ')" stroke="' + OL + '" stroke-width="' + sw + '" stroke-linejoin="round">' +
      '<path d="M62 -6 q18 8 14 30" fill="none"/><path d="M72 22 l8 10 l-12 0z" fill="' + st + '"/>' +
      '<rect x="-32" y="10" width="18" height="56" rx="8" fill="#fff"/><rect x="40" y="10" width="18" height="56" rx="8" fill="#fff"/>' +
      '<ellipse cx="14" cy="0" rx="56" ry="34" fill="#fff"/>' +
      '<rect x="-12" y="12" width="18" height="56" rx="8" fill="#fff"/><rect x="56" y="12" width="18" height="56" rx="8" fill="#fff"/>' +
      '<g fill="' + st + '" stroke="none"><path d="M0 -33 q6 20 -4 40 l8 0 q8 -20 2 -40z"/><path d="M22 -34 q8 24 0 50 l8 -2 q6 -24 -2 -48z"/><path d="M44 -28 q6 20 0 40 l7 -4 q4 -18 -1 -32z"/>' +
      '<rect x="-32" y="34" width="18" height="6"/><rect x="-32" y="48" width="18" height="6"/><rect x="40" y="34" width="18" height="6"/><rect x="40" y="48" width="18" height="6"/>' +
      '<rect x="-12" y="36" width="18" height="6"/><rect x="-12" y="50" width="18" height="6"/><rect x="56" y="36" width="18" height="6"/><rect x="56" y="50" width="18" height="6"/></g>' +
      '<path d="M-28 -20 L-52 -78 L-26 -88 L-6 -26Z" fill="#fff"/>' +
      '<path d="M-48 -84 Q-40 -100 -20 -92 L-10 -40 L-22 -36Z" fill="' + st + '"/>' +
      '<g fill="' + st + '" stroke="none"><path d="M-46 -64 l22 -6 l2 6 l-22 6z"/><path d="M-40 -46 l20 -6 l2 6 l-20 6z"/></g>' +
      '<ellipse cx="-50" cy="-104" rx="9" ry="16" fill="#fff" transform="rotate(-25 -50 -104)"/><ellipse cx="-30" cy="-108" rx="9" ry="16" fill="#fff" transform="rotate(10 -30 -108)"/>' +
      '<ellipse cx="-46" cy="-84" rx="28" ry="22" fill="#fff"/>' +
      '<ellipse cx="-66" cy="-72" rx="18" ry="14" fill="#cfc6d8"/>' +
      '<circle cx="-72" cy="-74" r="2.5" fill="' + OL + '" stroke="none"/><circle cx="-62" cy="-74" r="2.5" fill="' + OL + '" stroke="none"/>' +
      '<path d="M-72 -64 q6 5 12 0" fill="none" stroke-width="2.5" stroke-linecap="round"/>' +
      '</g><g transform="translate(' + x + ',' + y + ') scale(' + s + ')">' + eye(-48, -92, 7, -0.4) + eye(-30, -92, 6, -0.4) + cheek(-36, -74, 5) + '</g>';
  }

  // ---------- full puzzle scenes ----------
  const scenes = {
    ellie: function () {
      return svg(savanna('g1') + acacia(330, 200, 1.1) + flowers([[40, 250, '#ff7eb6'], [70, 268, '#ffd84d'], [360, 262, '#7ec8ff'], [300, 280, '#ff7eb6']]) +
        elephant(205, 190, 1.05, { bow: true }), sky('g1', '#7fcfff', '#dff5ff'));
    },
    family: function () {
      return svg('<rect width="400" height="300" fill="url(#g2)"/>' + sun(60, 50, 20) + cloud(250, 40, .9) + cloud(120, 70, .6) +
        '<path d="M0 180 Q120 150 230 175 T400 170 V300 H0Z" fill="#a5d977"/>' +
        '<ellipse cx="200" cy="262" rx="150" ry="26" fill="#5bc0eb" stroke="#3b93c4" stroke-width="3"/>' +
        '<path d="M90 262 q10 -4 20 0 M150 270 q10 -4 20 0 M240 258 q10 -4 20 0 M290 268 q10 -4 20 0" stroke="#fff" stroke-width="2.5" fill="none" stroke-linecap="round"/>' +
        palm(30, 210, .9) + palm(375, 205, .8) +
        elephant(250, 170, .95, {}) + elephant(120, 212, .58, { hat: true, color: '#b9c3cf' }) +
        '<g fill="#bfe9ff" stroke="#5bc0eb" stroke-width="1.5"><circle cx="40" cy="120" r="5"/><circle cx="52" cy="106" r="4"/><circle cx="62" cy="96" r="3"/></g>',
        sky('g2', '#ffd7a8', '#fff3d6'));
    },
    lion: function () {
      return svg(savanna('g3') + acacia(70, 210, .9) + flowers([[340, 262, '#ffd84d'], [370, 248, '#ff7eb6']]) + lion(220, 175, 1.05), sky('g3', '#ffcf8a', '#fff1c9'));
    },
    giraffe: function () {
      return svg(savanna('g4') + acacia(300, 205, 1.3) + giraffe(205, 200, 1.0), sky('g4', '#86d6ff', '#e8f8ff'));
    },
    monkey: function () {
      let leaves = '';
      const L = [[0, 0, 60], [60, -10, 50], [340, 0, 60], [400, 20, 55], [20, 300, 60], [390, 300, 60]];
      L.forEach(function (l) { leaves += '<circle cx="' + l[0] + '" cy="' + l[1] + '" r="' + l[2] + '" fill="#3f9b48"/><circle cx="' + (l[0] + 20) + '" cy="' + (l[1] + 16) + '" r="' + (l[2] * .7) + '" fill="#58b85a"/>'; });
      return svg('<rect width="400" height="300" fill="url(#g5)"/>' + '<rect x="0" y="230" width="400" height="70" fill="#6cc05a"/>' +
        '<path d="M70 0 Q60 140 90 230" stroke="#6b8e3a" stroke-width="5" fill="none"/><path d="M330 0 Q345 120 320 230" stroke="#6b8e3a" stroke-width="5" fill="none"/>' +
        
        leaves + monkey(200, 160, 1.0), sky('g5', '#bdf0c4', '#f0fff2'));
    },
    hippo: function () {
      return svg('<rect width="400" height="300" fill="url(#g6)"/>' + sun(330, 50, 20) + cloud(60, 50, .9) +
        '<path d="M0 150 Q100 130 200 150 T400 145 V300 H0Z" fill="#9fd773"/>' +
        '<rect x="0" y="200" width="400" height="100" fill="#4fb3e8"/>' +
        hippo(180, 200, 1.05) +
        '<path d="M0 220 q25 -10 50 0 t50 0 t50 0 t50 0 t50 0 t50 0 t50 0 t50 0 V300 H0Z" fill="#4fb3e8" opacity=".92"/>' +
        '<path d="M40 250 q10 -4 20 0 M300 240 q10 -4 20 0 M340 270 q10 -4 20 0" stroke="#fff" stroke-width="2.5" fill="none" stroke-linecap="round"/>' +
        '<g transform="translate(320,226)"><ellipse rx="26" ry="9" fill="#58b85a" stroke="' + OL + '" stroke-width="2"/><circle cx="6" cy="-6" r="7" fill="#ff9ecb" stroke="' + OL + '" stroke-width="2"/></g>',
        sky('g6', '#8fd8ff', '#e9f8ff'));
    },
    panda: function () {
      let bam = '';
      [[30, 0], [70, 10], [340, 0], [375, 15]].forEach(function (b) {
        bam += '<rect x="' + b[0] + '" y="' + b[1] + '" width="14" height="260" rx="5" fill="#7cc35a" stroke="#4f9a3a" stroke-width="2"/>' +
          '<path d="M' + b[0] + ' ' + (b[1] + 70) + ' h14 M' + b[0] + ' ' + (b[1] + 140) + ' h14 M' + b[0] + ' ' + (b[1] + 210) + ' h14" stroke="#4f9a3a" stroke-width="2"/>' +
          '<path d="M' + (b[0] + 14) + ' ' + (b[1] + 70) + ' q24 -14 34 -4 q-18 0 -34 4z" fill="#5aa54a"/>';
      });
      return svg('<rect width="400" height="300" fill="url(#g7)"/>' + cloud(150, 40, .9) + bam +
        '<path d="M0 220 Q200 190 400 220 V300 H0Z" fill="#8fcf5c"/>' + grassTufts(16, 230, 11) + panda(200, 165, 1.05), sky('g7', '#d2f5d0', '#f6fff2'));
    },
    turtle: function () {
      return svg('<rect width="400" height="300" fill="url(#g8)"/>' + sun(60, 50, 20) + cloud(250, 50, .9) +
        '<rect x="0" y="120" width="400" height="70" fill="#38b6e8"/>' +
        '<path d="M0 135 q20 -6 40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0" stroke="#fff" stroke-width="3" fill="none"/>' +
        '<path d="M0 180 Q200 160 400 185 V300 H0Z" fill="#f7dc9c"/>' + palm(360, 220, .9) +
        '<g transform="translate(70,262)"><path d="M0 0 l8 -14 l8 14 l-8 -4z" fill="#ff8a65" stroke="' + OL + '" stroke-width="2"/></g>' +
        '<g transform="translate(320,270)"><circle r="7" fill="#fff" stroke="' + OL + '" stroke-width="2"/><path d="M-5 -2 q5 4 10 0" stroke="#ff9ecb" stroke-width="2" fill="none"/></g>' +
        turtle(220, 225, 1.05), sky('g8', '#7fd4ff', '#e3f7ff'));
    },
    owl: function () {
      let stars = '';
      [[40, 40], [120, 70], [200, 30], [260, 80], [360, 50], [90, 130], [330, 140]].forEach(function (p) {
        stars += '<path d="M' + p[0] + ' ' + (p[1] - 6) + ' l2 4 l5 1 l-4 3 l1 5 l-4 -2 l-4 2 l1 -5 l-4 -3 l5 -1z" fill="#fff3a6"/>';
      });
      return svg('<rect width="400" height="300" fill="url(#g9)"/>' + stars +
        '<circle cx="330" cy="70" r="30" fill="#fff6c9"/><circle cx="342" cy="62" r="26" fill="#3d3a7a"/>' +
        '<path d="M0 240 Q200 210 400 240 V300 H0Z" fill="#2f6b4f"/>' +
        '<path d="M40 300 L40 160 M40 200 L240 196" stroke="#6b4423" stroke-width="16" stroke-linecap="round"/>' +
        '<circle cx="40" cy="140" r="50" fill="#2f7a55"/>' +
        owl(190, 120, 1.05) +
        '<path d="M150 196 h90" stroke="#6b4423" stroke-width="14" stroke-linecap="round"/>' +
        '<g fill="#ffe86b"><circle cx="300" cy="200" r="3"/><circle cx="340" cy="230" r="3"/><circle cx="110" cy="250" r="3"/></g>',
        sky('g9', '#2b2a5e', '#5b4f9e'));
    },
    zebra: function () {
      return svg(savanna('g10') + acacia(320, 210, 1.0) + flowers([[40, 260, '#ff7eb6'], [70, 272, '#ffd84d']]) + zebra(205, 190, 1.0), sky('g10', '#a2e1ff', '#f0fbff'));
    }
  };

  function mascot(mood) {
    // Ellie head for the corner helper
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-110 -110 140 160">' + elephant(0, 0, 1, { bow: true }).replace(/<rect[^>]*>/g, '') + '</svg>';
  }

  window.ART = {
    scenes: scenes,
    mascotSVG: mascot,
    elephantSVG: function (opt) {
      return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-120 -110 240 190">' + elephant(0, 0, 1, opt || { bow: true }) + '</svg>';
    }
  };
})();
